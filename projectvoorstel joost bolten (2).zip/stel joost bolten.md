# Projectvoorstel Joost Bolten

## Probleem
Een vies huis. Overal staat vaat, de vloer plakt van het bier en er groeit schimmel uit de koelkast. Herkenbaar? Voor veel samenwonende studenten wel. Studentenhuizen zijn notoir voor hun gebrek aan hygiëne, maar dat hoeft niet zo te zijn. Een groot probleem in het schoonhouden van een huis - zeker naarmate het aantal huisgenoten toeneemt - is communicatie. Wie heeft wat vies gemaakt? Wie moet wat weer schoon maken? Het spreekt voor zich dat niemand zich geroepen voelt om andermans zooi aan kant te maken. Dit zorgt in veel studentenhuizen voor een verlammende werking. Vuil stapelt zich op, en niemand doet er meer iets aan. 

## Oplossing
De oplossing voor dit probleem heet "Schoonmaakdashboard". Met de tool die ik ga ontwikkelen tijdens dit project maak je gemakkelijk en snel schoonmaakroosters. Dit zal studenten helpen om duidelijkheid te creëren over wie wat moet doen in het verzorgen van hun huis. 

Het programma werkt als volgt: per huishouden maakt elke huisgenoot een account aan. Één van de huisgenoten wordt aangewezen als de admin, hij/zij krijgt extra mogelijkheden binnen de webapp. De admin is onder meer verantwoordelijk voor het aanmaken van taken, het aanmaken van groepen binnen de huisgenoten en het beheren van de boetes.

Als stok achter de deur werkt het roosterprogramma namelijk met een boetesysteem. Als een huisgenoot zijn/haar taak niet doet, krijgen ze een boete. De hoogte van deze boete kan bepaald worden door de admin. 

Voor de huisgenoten functioneert de webapp als een dashboard, waarop alle relevante informatie rondom het schoonmaakrooster op één handige pagina verzameld is. Deze informatie bestaat uit de taak die gedaan moet worden, informatie over de boete die ze hebben en informatie over de boetes van huisgenoten - bedoelt als een 'name & shame' voor mensen die hun steentje niet bijdragen. Op deze pagina kunnen huisgenoten het ook aangeven als ze hun taak gedaan hebben.

## Doelgroep
Dit programma is specifiek geschikt voor studentenhuizen. Dat komt door een aantal features. Allereerst wordt de opgebouwde boete omgerekend naar liters bier, waardoor de student een tastbare representatie van de kosten van niet schoonmaken ziet. Ook heeft de pagina een opvallende kleur en zijn er op een aantal plekken smiley's toegevoegd. Dit is om de aandacht van de student beter vast te houden. Daarnaast is het mogelijk voor de admin om de huisgenoten op te delen in groepen. Deze groepen kunnen dan wel/niet op bepaalde taken gezet worden. Hierdoor kan rekening gehouden met voorkeuren en is het programma ook geschikt voor huizen met meerdere gangen die apart van elkaar functioneren.

# Sketches
### Login page
![Login page](https://lh3.googleusercontent.com/pw/ADCreHeo7hH6VYa--Lz-locohQxFxz1AKOdiNRpiDu4LgpXJ1FYIG9d316121guYAVCEJXMZ1rMzk37n30I-dGnHlWmj73t8-znMzsf6ftHZhROQ7DWJ5_761CRwjTa7KkwSYDMnjgVunGbHeoOPKa6kWrXyFkjxUxvrVTqy96CxTWNSBd12ONuG2x7CfuujfuuS2uFJq_R2YH5shVjoGHW4OEu4u5VUy5oNEA-mJDk_1yXfjr2DXmlH7d3Z9ltkHz8to5hxgJggALM7E3gs2lPLx594Ag5pSbyiZgqYz-0iYObM0mCIZFZaDHMY0KmPCTYnMX-UBki3asLR54_b17UofQEd2b-HtWgKAfKOFU9CM0VhmjJLVkboo7NzPB3wjUz64uz_2eR0johHVWBj_HNdbiqRxlbHjnZaZmY4wf6KFQmUIxw-ehRjGsqG0RDzUrfSFGqfTZ6cVijxXiA1wJZfzQwhLfHcd0osgtqrkMWK3aal4lk2FEYaKqCr92cNrbsyW1teZUajgJeTzXjigTx9KP3bfIFOCgWq3xRcomdQ_83Nt2bpjsqHm9ToUt1TSdAM3X1xfjcYYOXp-BHcnzEhB4cb7qqhnj3VJkl_qkSzWdekrKOp4ZAk0UIPvMM04rsqTRHshRlnLRgRx3qNRRnmvTEOWZzNeui4PI245BROD1sc2McBTiISX2W0O3JnROebtzuTnKbEmGzjTxwsC2oGtXOdypc23P2HKGtX7f1pB-WCJ6oSgEw8traBQ8qtH5TVvbs7av4IZtNrIBy_iIaM0skB1lDzfXtAeeFYPbaceOw8VevFk9lNWvBhqPlDjlKn_zO8RtdkhkL5OzEbrFdqwesGjj5x1Z9U-E2U83i-yNxrB7EZHDLyNhQjB_xhQLLy16LlGdCClK8z7R_rLcHGWGEyAkY=w959-h628-s-no-gm?authuser=0)
Dit is de login-page. Hier kan de gebruiker een account aanmaken of inloggen.
### Main dashboard
![Dashboard](https://lh3.googleusercontent.com/pw/ADCreHcXt34HJ9fF2yB1GZQfK71qb9mfyb2zUxw6X_qA9sbV8WoORfHBHv7ZFLhHzXupKHHGyvUGUwMWHgA9PG0hJF05WGXZ8aLkL7ctlMRpMg0VHgm-V7VVPsDrnyI0nme8_wjJP87sChLxjwRjumyTMYRbW0TI3umeShQ_rE0aXc9fz5Ofk4gvYlCF-MEvDFzmzoQhXGm5p71eTeD_1SugwxDa1eoMwv67R3Xm_4WdbJTn2IJLI5bT8epneZLFwI9M0IPMwua59VP61H3ttrtetLa-QRX7QX-Z_tYYJpK9a0jTYE_VDN-66STPjL9hQNAN5_Vtv1QFj4Mi4wwWB2tARmbM7VRGQayOPsgRqbbM2ky2dv7iq1QVzgqILu98MDntOv28UdU034gE5cVnQrwcKTI6wd-Wz6a94N86yC8WmnjsdNnd2AAuBX62VL68CDbag6EOvuVpLaxzonsB0xS7tRvdBEwNHVJDKNYBF-cWw5GM4ff3B2r-HItNi0efQTZMtrHS3oVwxBQoU9nQCA97JnaIhsPVn9zxzqNeAFzE1MJLVsv9Jh84NxIu1srtLFCd0uy4NJSLQQCavormtMevfFYbG2DXv_JyGTPzcT8aYzuH4JGwB1I7Zf26-ogMloz2az-GlXpAWbKehE_3sbIj4TWv6UiSSTQWPcjbVZF8F3ZZNRgfMTX-yMbdYd7hbWjMdpomP1DW9TVvsVMcSAdgkIB-pT9BTAvloqnEd8wWYmHfkg53oVrAKuhhB2fXFZAQw09MG014m0fmcSaoF28wUTq6Q5B1JNNtj8-rvS-MOlabflVneGR_Mv1j_cLIiwdHCSGzfsis4cVx9G3Lzubf68CDVezEfpTMvzKgn3rXiFAbiQxcaxRzb5kkrmcDLHCsLjo9q-UT9TfF-JghD4o7AQA26nU=w959-h625-s-no-gm?authuser=0)
Dit is de main-page. Hier kan de gebruiker zien welke taak ze hebben, hoeveel boete ze hebben en hoe het met hun huisgenoten gaat.
### Admin page
![Admin page](https://lh3.googleusercontent.com/pw/ADCreHdbz-uhF8EQTOZrvJnC9IQDrJkyXir-e_drKycYdYH-GtclVy6XvMN03LtC3YlZbwnBh3qZXQykPJBmMyQ_0KwbwXOINvVV0mcW2Ha9xY2R3TzDfR0R48nMKF9Y-MefroCuGASE-Dd0wbt9OkLGcnasO8YaxDb9Gu0JV-bgpHwouI4KVEGtrS6JIsO2pXBGXiXoJdXs-bc20N4ZceaEaoiic_RlPtBo8EBs1eUgW_NGPOl5hhtovCk7RpZgfoRD05BiWS-XCCyFZPhwtsKY-Uz0OZyev7Fg6FB4xVmVR7akAjGT1-bzYViWV_vPYhJsycv3IttE_w5Sctm4MVTpzQ99K6F30WVjXh1QahRWQoIilP6FyGB3SfOhfA1uigCpyqeH8J7EEfvMGuRsQVnQx_D5DlZWZuOyavq7IsouXzgWx_M9ul4f_vKa3oTb4mEMvvoBnaITCNpTxj2yZg6y_nY5yM4Pop9MwfDpxMJB2yTTQ54t_lNDpbauSGxureg1hjFXgO5A40noTYq2WXfzl1aLkq-YHl6xfN3Z-C0MThfFnzHlryV6f5ZghFHVAhwx_8sfspshWNLIcG0QsYhVBekDbAVzRROtdIYjTRuJCz5ybYhhwu-RjLISMcx3tHmkCENz8vDB-GlehyrQoyqwyjDeIQKT5mpt_7TkvbBojwqF_wOKgvisgt1_R7E7sLAfv74VaLHqde_OCmItn5dCExWzlPtmw2jBKwKSeSZuWVFydgsD44NL-aSObpwbGPdHjkc2BdxGunIjJEc36QlgPsG-ghXDVlH8waDUgFQNYhCv6yQaMfByadeUZaEowPVvv3D0PX5xmzWBWtHfrGCO75Wo9fJoO_B69LtUUMZZW_T_DwA4LqdDdUN0-WZawKaDr3tdtp0QobSJRrAHnPbaW4Z8-L8=w959-h619-s-no-gm?authuser=0)
Dit is de admin page. Hier kan de aangewezen admin wijzigingen maken aan het rooster, de mensen in het huis, de groepen binnen het huis, en de boetes.

# Features
### Essentiële features
* Users creëren
* Users groeperen in huizen
* Users admin status kunnen geven
* Inloggen
* Bijhouden van taken en boetes per user
* Algoritme om rooster te creëren

### Niet-essentiële features
* Groepen creëren in huizen
* Roosters laten outputten in excel
* Omrekenen van boetes naar liters bier
* Opmaak perfectioneren

# Requirements
* Openpyxl (python-excel integration)
* Sqlalchemy & cs50 sql library
* Flask

# Moelijk
Wat gaan de mogelijke struikelblokken worden in dit project?

- Het creëren van een adaptive algoritme dat eerlijke roosters maakt op basis van eerder gedane taken (zodat mensen even vaak elke taak doen). Daarnaast moet het algoritme in staat zijn om te denken met groepen binnen de huizen.
- Het werken met excel en python, ik heb eerder geprobeerd om een simpel python programma te schrijven voor dit doeleinde, die de roosters zou outputten in excel bestanden. Hier ben ik best even mee bezig geweest, dit ging echter voor geen meter.